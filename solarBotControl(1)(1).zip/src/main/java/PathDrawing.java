import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.util.ArrayList;

public class PathDrawing extends JFrame {
    private BufferedImage image;
    private Point startPoint;
    private Point endPoint;
    private ArrayList<Line> lines = new ArrayList<>(); // Store lines based on selected direction
    private JRadioButton verticalButton; // Radio button for vertical lines
    private JRadioButton horizontalButton; // Radio button for horizontal lines
    private Line selectedLine; // Currently selected line for dragging
    private Point previousMousePoint; // Store previous mouse point for dragging

    public PathDrawing(Main mainFrame) {
        setTitle("Path Drawing");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Load image
        loadImage();

        // Create panel for direction selection
        JPanel directionPanel = new JPanel();
        verticalButton = new JRadioButton("Vertical", true); // Default to vertical
        horizontalButton = new JRadioButton("Horizontal");
        ButtonGroup group = new ButtonGroup();
        group.add(verticalButton);
        group.add(horizontalButton);
        directionPanel.add(verticalButton);
        directionPanel.add(horizontalButton);

        add(directionPanel, BorderLayout.NORTH); // Add the direction selection panel

        // Panel for drawing
        JPanel drawPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (image != null) {
                    g.drawImage(image, 0, 0, null); // Draw the image
                }
                drawLines(g); // Draw the selected direction lines
            }
        };

        drawPanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (startPoint == null) {
                    startPoint = e.getPoint(); // Set start point
                } else if (endPoint == null) {
                    endPoint = e.getPoint(); // Set end point
                    generateLines(); // Generate lines based on selection
                    drawPanel.repaint(); // Repaint the panel
                } else {
                    // Check if a line was clicked for dragging
                    for (Line line : lines) {
                        if (line.contains(e.getPoint())) {
                            selectedLine = line;
                            previousMousePoint = e.getPoint();
                            break;
                        }
                    }
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                selectedLine = null; // Clear the selected line when the mouse is released
            }
        });

        drawPanel.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                if (selectedLine != null) {
                    // Update the line position based on the mouse movement
                    int dx = e.getX() - previousMousePoint.x;
                    int dy = e.getY() - previousMousePoint.y;

                    // Move the selected line by the change in mouse position
                    selectedLine.move(dx, dy);
                    previousMousePoint = e.getPoint();
                    drawPanel.repaint(); // Repaint the panel to show updated line position
                }
            }
        });

        add(drawPanel, BorderLayout.CENTER);
        setVisible(true);
    }

    private void loadImage() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Select Image");
        if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            try {
                image = ImageIO.read(file);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void generateLines() {
        lines.clear(); // Clear existing lines
        if (startPoint != null && endPoint != null) {
            // Calculate the number of lines
            int numberOfLines = 10; // Adjust this value as needed

            if (verticalButton.isSelected()) {
                // Generate vertical lines
                double deltaX = (endPoint.getX() - startPoint.getX()) / numberOfLines;
                for (int i = 0; i <= numberOfLines; i++) {
                    int x = (int) (startPoint.getX() + deltaX * i);
                    lines.add(new Line(x, startPoint.y, x, endPoint.y)); // Full height of the grid
                }
            } else if (horizontalButton.isSelected()) {
                // Generate horizontal lines
                double deltaY = (endPoint.getY() - startPoint.getY()) / numberOfLines;
                for (int i = 0; i <= numberOfLines; i++) {
                    int y = (int) (startPoint.getY() + deltaY * i);
                    lines.add(new Line(startPoint.x, y, endPoint.x, y)); // Full width of the grid
                }
            }
        }
    }

    private void drawLines(Graphics g) {
        g.setColor(Color.RED); // Color for grid lines
        // Draw lines based on the selection
        for (Line line : lines) {
            g.drawLine(line.x1, line.y1, line.x2, line.y2);
        }

        // Draw start and end points
        if (startPoint != null) {
            g.setColor(Color.GREEN);
            g.fillOval(startPoint.x - 5, startPoint.y - 5, 10, 10); // Draw start point
            g.setColor(Color.BLACK);
            g.drawString("Start", startPoint.x + 10, startPoint.y); // Draw start label
        }
        if (endPoint != null) {
            g.setColor(Color.BLUE);
            g.fillOval(endPoint.x - 5, endPoint.y - 5, 10, 10); // Draw end point
            g.setColor(Color.BLACK);
            g.drawString("End", endPoint.x + 10, endPoint.y); // Draw end label
        }
    }

    private static class Line {
        int x1, y1, x2, y2;

        Line(int x1, int y1, int x2, int y2) {
            this.x1 = x1;
            this.y1 = y1;
            this.x2 = x2;
            this.y2 = y2;
        }

        // Check if the point is near the line segment
        boolean contains(Point p) {
            // Use a threshold distance to determine if the point is close to the line
            int threshold = 5; // Adjust this value as needed
            return (Math.abs((y2 - y1) * p.x - (x2 - x1) * p.y + x2 * y1 - y2 * x1) / 
                    Math.sqrt(Math.pow(y2 - y1, 2) + Math.pow(x2 - x1, 2))) < threshold;
        }

        // Move the line by a delta in x and y
        void move(int dx, int dy) {
            this.x1 += dx;
            this.y1 += dy;
            this.x2 += dx;
            this.y2 += dy;
        }
    }
}
