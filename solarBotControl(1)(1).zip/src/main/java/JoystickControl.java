import javax.swing.*;
import java.awt.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class JoystickControl extends JFrame {
    private Main parent;
    private JSlider leftJoystick;
    private JSlider rightJoystick;
    private JLabel leftValueLabel;
    private JLabel rightValueLabel;

    public JoystickControl(Main parent) {
        this.parent = parent;
        setTitle("Joystick Control");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Layout: sliders side by side
        setLayout(new GridLayout(1, 4));

        // Left Joystick
        leftJoystick = createJoystick("Left Joystick");
        leftValueLabel = new JLabel("Left: 0");

        // Right Joystick
        rightJoystick = createJoystick("Right Joystick");
        rightValueLabel = new JLabel("Right: 0");

        // Add sliders and labels to the frame side by side
        add(leftValueLabel);
        add(leftJoystick);
        add(rightValueLabel);
        add(rightJoystick);

        setVisible(true);
    }

    private JSlider createJoystick(String title) {
        JSlider slider = new JSlider(JSlider.VERTICAL, -100, 100, 0);
        slider.setMajorTickSpacing(50);
        slider.setMinorTickSpacing(10);
        slider.setPaintTicks(true);
        slider.setPaintLabels(true);
        slider.setSnapToTicks(true);

        // Add change listener to handle slider value changes
        slider.addChangeListener(new JoystickChangeListener(title));

        // Add mouse listener to reset slider on release
        slider.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                slider.setValue(0); // Reset the slider value to 0 when released
                parent.sendCommandToRobot("STOP"); // Send stop command to robot on release
            }
        });

        return slider;
    }

    private class JoystickChangeListener implements ChangeListener {
        private String joystickName;

        public JoystickChangeListener(String joystickName) {
            this.joystickName = joystickName;
        }

        @Override
        public void stateChanged(ChangeEvent e) {
            JSlider source = (JSlider) e.getSource();
            int value = source.getValue();

            // Update the label and send appropriate commands
            if (joystickName.equals("Left Joystick")) {
                leftValueLabel.setText("Left: " + value);
                if (value != 0) {
                    parent.sendCommandToRobot("LEFT_MOVE " + value);
                }
            } else if (joystickName.equals("Right Joystick")) {
                rightValueLabel.setText("Right: " + value);
                if (value != 0) {
                    parent.sendCommandToRobot("RIGHT_MOVE " + value);
                }
            }
        }
    }
}
