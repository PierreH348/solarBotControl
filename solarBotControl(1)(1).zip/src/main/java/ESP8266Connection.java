import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;

public class ESP8266Connection extends JFrame {
    private Main parent;
    private JComboBox<String> deviceList;
    private JTextField passwordField;

    public ESP8266Connection(Main parent) {
        this.parent = parent;
        setTitle("ESP8266 Connection");
        setSize(400, 200);
        setLayout(new GridLayout(3, 2));

        deviceList = new JComboBox<>(new String[]{"Select Device", "ESP8266-1", "ESP8266-2", "ESP8266-3"});
        passwordField = new JTextField();

        add(new JLabel("Select Device:"));
        add(deviceList);
        add(new JLabel("Password:"));
        add(passwordField);

        JButton connectButton = new JButton("Connect");
        connectButton.addActionListener(e -> connectToDevice());
        add(connectButton);
    }

    private void connectToDevice() {
        String selectedDevice = (String) deviceList.getSelectedItem();
        if (selectedDevice.equals("Select Device")) {
            JOptionPane.showMessageDialog(this, "Please select a device!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Check password
        String password = passwordField.getText();
        if (password.equals("1995")) {
            try {
                // Simulate connecting to the ESP8266 device
                parent.setConnectionStatus(true, new PrintWriter(System.out, true)); // Replace with actual connection logic
                JOptionPane.showMessageDialog(this, "Connected to " + selectedDevice, "Success", JOptionPane.INFORMATION_MESSAGE);
                dispose(); // Close connection window
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Connection Failed: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Failed to connect. Incorrect password!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
